
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (1,'Artisan 常用命令',1,'<p><img alt=\"timg.jpg\" src=\"/uploads/images/blogs201804/14/1523674094_PVt94RSMKE.jpg\" width=\"1024\" height=\"526\"><br></p><p>php artisan key:generate生成 App Key</p><p><br>php artisan make:controller生成控制器</p><p><br>php artisan make:model生成模型&nbsp;<span style=\"color: rgb(51, 51, 51); font-size: 16px;\">-m参数生成迁移文件</span></p><p><br></p><p>php artisan make:policy生成授权策略</p><p><br>php artisan make:seeder生成 Seeder 文件</p><p><br>php artisan migrate执行迁移</p><p><br>php artisan migrate:rollback回滚迁移</p><p><br>php artisan migrate:refresh重置数据库</p><p><br>php artisan db:seed填充数据库</p><p><br>php artisan tinker进入 tinker 环境</p><p><br>php artisan route:list查看路由列表</p>',1,'2018-04-13 06:03:00','2018-04-14 02:48:29'),(2,'本小站的技术栈',1,'<p><b>PHP7.1</b></p><p><b><img alt=\"下载 (1).png\" src=\"/uploads/images/blogs201804/14/1523708482_6odMNubyRB.png\" width=\"318\" height=\"159\"><br></b></p><p><b>mysql5.6</b></p><p><b><img alt=\"下载 (2).png\" src=\"/uploads/images/blogs201804/14/1523708519_6cRVDrUjeG.png\" width=\"312\" height=\"161\"><br></b></p><p><b><br></b></p><p><b>Jquery</b></p><p><b><img alt=\"下载 (3).png\" src=\"/uploads/images/blogs201804/14/1523708558_swhObWMVoX.png\" width=\"290\" height=\"174\"><br></b></p><p><b><br></b></p><p><b>Materialize</b></p><p><b><img alt=\"下载 (4).png\" src=\"/uploads/images/blogs201804/14/1523708643_6AseIAXNIM.png\" width=\"225\" height=\"225\"><br></b></p><p><b>Nginx</b></p><p><b><img alt=\"下载 (5).png\" src=\"/uploads/images/blogs201804/14/1523708789_IydVluoOYM.png\" width=\"211\" height=\"239\"><br></b></p><p><b><br></b></p>',3,'2018-04-14 12:24:13','2018-04-14 12:26:51'),(3,'服务器的购买',1,'<p>这里我推荐使用国外的<a href=\"https://www.vultr.com/\" target=\"_blank\">vultr</a>，因为他的价格合理（按小时计费2.5美元一个月），还可以搭建梯子！</p><blockquote><p>搭建梯子可以参考这篇文章<a href=\"https://www.flyzy2005.com/fan-qiang/shadowsocks/build-shadowsocks-on-vps/\" target=\"_blank\">VPS上搭建shadowsocks</a></p></blockquote><p><b>1.注册一个账号</b></p><p><img alt=\"image.png\" src=\"/uploads/images/blogs201804/14/1523709210_vc2hsDFQUd.png\" width=\"800\" height=\"314.6666666666667\"><br></p><p><b>2.创建一个新的实例</b></p><p><b><img alt=\"image.png\" src=\"/uploads/images/blogs201804/14/1523709398_HxnBM33Ih8.png\" width=\"800\" height=\"200\"><br></b></p><p>选择一个地区，我自己选择的是东京因为直连比较快但是要5美元一个月。</p><p>操作系统选择ubuntu16*64。</p><p>把ipv6勾打上创建！</p><p><img alt=\"image.png\" src=\"/uploads/images/blogs201804/14/1523709680_70rl4su6L4.png\" width=\"800\" height=\"427.34375\"><br></p><p>可以使用支付宝付款！！</p><p><span style=\"color: rgb(51, 51, 51); font-size: 16px;\">可以使用支付宝付款！！</span><br></p><p><span style=\"color: rgb(51, 51, 51); font-size: 16px;\"><span style=\"color: rgb(51, 51, 51); font-size: 16px;\">可以使用支付宝付款！！</span><br></span></p><p><b>3.到Servers查看实例信息</b></p><p>使用cmd ping命令查看服务器是否能直连，如果不能请删除重新创建。</p><p><img alt=\"image.png\" src=\"/uploads/images/blogs201804/14/1523709882_mkfYR7XsQ8.png\" width=\"800\" height=\"225.78125\"><br></p><p>到此服务器购买到创建完毕！</p>',3,'2018-04-14 12:45:52','2018-04-14 13:23:33'),(4,'域名的购买',1,'<p><a href=\"https://www.namesilo.com/\" target=\"_blank\">namesilo</a><br></p>',3,'2018-04-14 12:48:04','2018-04-14 12:48:04'),(5,'Artisan 常用命令',1,'<p><img alt=\"timg.jpg\" src=\"/uploads/images/blogs201804/14/1523710930_nqJss297Nb.jpg\" width=\"1024\" height=\"526\"><br></p><p>php artisan key:generate生成 App Key</p><p><br>php artisan make:controller生成控制器</p><p><br>php artisan make:model生成模型</p><p><br>php artisan make:policy生成授权策略</p><p><br>php artisan make:seeder生成 Seeder 文件</p><p><br>php artisan migrate执行迁移</p><p><br>php artisan migrate:rollback回滚迁移</p><p><br>php artisan migrate:refresh重置数据库</p><p><br>php artisan db:seed填充数据库</p><p><br>php artisan tinker进入 tinker 环境</p><p><br>php artisan route:list查看路由列表<br><br></p>',4,'2018-04-14 13:02:22','2018-04-14 13:02:22');
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `backimg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '/images/backimg.jpg' COMMENT '背景图片',
  `post_count` int(11) NOT NULL DEFAULT '0' COMMENT '帖子数',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_name_index` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (9,'111','1','/images/backimg.jpg',0,'2018-04-16 05:27:46','2018-04-16 05:27:46');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2018_04_10_145222_seed_users_data',1),(4,'2018_04_10_150331_create_blogs_tanle',1),(5,'2018_04_12_071851_create_categories_table',1),(6,'2018_04_16_014319_edit_backimg_to_categories_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','945469282@qq.com','$2y$10$vU3tvOu2U2w5RvxQLRZ1quUTuTlKtpir75U0WUMe4Mp1cfyrl.ZsC','kdafpgrT3aXEtKrXlozjp2qms0iFNAfASSigNbHxMoH9SBJgYQ7evMQsvflO',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

